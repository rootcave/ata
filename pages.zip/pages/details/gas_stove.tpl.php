
<body>

<!-- Container -->
<div id="container">



    <!-- Slider -->
    <!--    <div id="banner">-->
    <!--        <div class="container">-->
    <!--            <ul class="bxslider">-->
    <!--                <li>-->
    <!--                    <p>We Design & Develop Awesome <span> Websites</span> and smart <span> applications</span>, Impactful <span> Identities</span> Using The Latest Technologies</p>-->
    <!--                </li>-->
    <!--                <li>-->
    <!--                    <p>How to turn off <span> banners</span> that appear on top of page for good?</p>-->
    <!--                </li>-->
    <!--                <li>-->
    <!--                    <p>Duis sed odio sit amet <span> nibh</span> vulputate cursus a sit amet mauris. <span> Morbi</span> accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor</p>-->
    <!--                </li>-->
    <!--            </ul>-->
    <!--        </div>-->
    <!--    </div>-->
    <!-- End Slider -->

    <!-- Content -->
    <div class="content" style="margin-top: 120px;">
        <div class="container">
            <section class="single-work">
                <h2><span>البوتاجازات </span></h2>
                <div class="row-fluid">

                    <!-- project-box -->
                    <div class="span8 blog-box">

                        <!-- project post -->
                        <div class="blog-post slider-post">
                            <div class="post-content">
                                <div class="flexslider">
                                    <ul class="slides">
                                        <li>
                                            <img alt="" src="<?= IMG_DIR; ?>products/flat.jpg" />
                                        </li>




                                    </ul>
                                </div>

                                <div class="block">
                                    <input type="radio" name="feature" id="featureA" class="accordionRadio" checked />
                                    <label for="featureA" class="accordionLabel"><span class="accordionSpan arabic">مصطح 3 عين  </span></label>
                                    <div class="info-sm">

                                        <p class="arabic">                                    جسم استيلس غير قابل للصداء
                                        </p>
                                        <p class="arabic">                                   اشعال ذاتي
                                        </p>
                                        <p class="arabic">                                   شعله زهر
                                        </p>
                                        <p class="arabic">                                    شكل يناسب البيت العصري
                                        </p>
                                    </div>
                                </div>

                            </div>

                        </div>
                        <!-- End project post -->

                    </div>

                    <!-- sidebar -->
                    <div class="span4 sidebar">
                        <ul class="widgets">

                            <li class="what-we-do-widget widget arabic">

                                <h3 class="arabic" style="color: #315ba6;">    </h3>
                                <ul class="arabic">

                                </ul>

                            </li>


                        </ul>

                    </div>

                </div>
            </section>
        </div>
    </div>
    <!-- End content -->

