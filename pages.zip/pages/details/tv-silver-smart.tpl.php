
<body>

<!-- Container -->
<div id="container">



    <!-- Slider -->
    <!--    <div id="banner">-->
    <!--        <div class="container">-->
    <!--            <ul class="bxslider">-->
    <!--                <li>-->
    <!--                    <p>We Design & Develop Awesome <span> Websites</span> and smart <span> applications</span>, Impactful <span> Identities</span> Using The Latest Technologies</p>-->
    <!--                </li>-->
    <!--                <li>-->
    <!--                    <p>How to turn off <span> banners</span> that appear on top of page for good?</p>-->
    <!--                </li>-->
    <!--                <li>-->
    <!--                    <p>Duis sed odio sit amet <span> nibh</span> vulputate cursus a sit amet mauris. <span> Morbi</span> accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor</p>-->
    <!--                </li>-->
    <!--            </ul>-->
    <!--        </div>-->
    <!--    </div>-->
    <!-- End Slider -->

    <!-- Content -->
    <div class="content" style="margin-top: 120px;">
        <div class="container">
            <section class="single-work">
                <h2><span>شاشات SMART LED</span></h2>
                <div class="row-fluid">

                    <!-- project-box -->
                    <div class="span8 blog-box">

                        <!-- project post -->
                        <div class="blog-post slider-post">
                            <div class="post-content">
                                <div class="flexslider">
                                    <ul class="slides">
                                        <li>
                                            <img alt="" src="<?= IMG_DIR; ?>products/tv5.jpg" />
                                        </li>


                                    </ul>
                                </div>

                                
                               
                             
                                <div class="block">
                                    <input type="radio" name="feature" id="featureB" class="accordionRadio" checked />
                                    <label for="featureB" class="accordionLabel"><span class="accordionSpan arabic">شاشة SMART SILVER  32  LED</span></label>
                                    <div class="info-med">
                                        <p class="arabic">مدخل  USB  Movies / 2</p>
                                        <p class="arabic">مدخل   / HD  2</p>
                                        <p class="arabic">وضوح كامل للحركة  Full HD  1080 x 1920</p>
                                        <p class="arabic">إضاءة ذاتية للخلايا</p>
                                        <p class="arabic">VGA</p>
                                        <p class="arabic">صوت مجسم قوي ستريو</p>
                                        <p class="arabic">متعدد أنظمة الصوت والصورة </p>
                                        <p class="arabic">PPI  / 30000</p>
                                        <p class="arabic">مدخل  AV  / OUT    AV / IN 2   </p>
                                        <p class="arabic">مدخل LAN  +   WIFI</p>
                                    </div>
                                </div>

                                <div class="clearfix"></div>

                            </div>

                        </div>
                        <!-- End project post -->

                    </div>

                    <!-- sidebar -->
                    <div class="span4 sidebar">
                        <ul class="widgets">


                        </ul>

                    </div>

                </div>
            </section>
        </div>
    </div>
    <!-- End content -->

