
<body>

<!-- Container -->
<div id="container">

   

    <!-- Slider -->
<!--    <div id="banner">-->
<!--        <div class="container">-->
<!--            <ul class="bxslider">-->
<!--                <li>-->
<!--                    <p>We Design & Develop Awesome <span> Websites</span> and smart <span> applications</span>, Impactful <span> Identities</span> Using The Latest Technologies</p>-->
<!--                </li>-->
<!--                <li>-->
<!--                    <p>How to turn off <span> banners</span> that appear on top of page for good?</p>-->
<!--                </li>-->
<!--                <li>-->
<!--                    <p>Duis sed odio sit amet <span> nibh</span> vulputate cursus a sit amet mauris. <span> Morbi</span> accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor</p>-->
<!--                </li>-->
<!--            </ul>-->
<!--        </div>-->
<!--    </div>-->
    <!-- End Slider -->

    <!-- Content -->
    <div class="content" style="margin-top: 120px;">
        <div class="container">
            <section class="single-work">
                <h2><span>Single Work</span></h2>
                <div class="row-fluid">

                    <!-- project-box -->
                    <div class="span8 blog-box">

                        <!-- project post -->
                        <div class="blog-post slider-post">
                            <div class="post-content">
                                <div class="flexslider">
                                    <ul class="slides">
                                        <li>
                                            <img alt="" src="<?= IMG_DIR; ?>blog2.jpg" />
                                        </li>
                                        <li>
                                            <img alt="" src="<?= IMG_DIR; ?>blog3.jpg" />
                                        </li>
                                        <li>
                                            <img alt="" src="<?= IMG_DIR; ?>blog1.jpg" />
                                        </li>
                                    </ul>
                                </div>
                                <h1 style="color: #315ba6;">اى حاجة هنا</h1>
                                <p>اى كلام يتقال و خلاص المهم الحشو </p>
                                <p>اى كلام يتقال و خلاص المهم الحشو</p>
                            </div>

                        </div>
                        <!-- End project post -->

                    </div>

                    <!-- sidebar -->
                    <div class="span4 sidebar">
                        <ul class="widgets">

                            <li class="what-we-do-widget widget arabic">

                                <h3 class="arabic" style="color: #315ba6;">اى حاجة هنا</h3>
                                <ul class="arabic">
                                    <li class="arabic">اى كلام يتقال و خلاص المهم الحشو</li>
                                    <li class="arabic">اى كلام يتقال و خلاص المهم الحشو</li>
                                    <li class="arabic">اى كلام يتقال و خلاص المهم الحشو</li>
                                    <li class="arabic">اى كلام يتقال و خلاص المهم الحشو</li>
                                    <li class="arabic">اى كلام يتقال و خلاص المهم الحشو</li>
                                </ul>

                            </li>

                            <li class="what-we-do-widget widget arabic">
                                <h3 class="arabic" style="color: #315ba6;">اى حاجة هنا</h3>
                            <ul class="arabic">
                                <li class="arabic">اى كلام يتقال و خلاص المهم الحشو</li>
                                <li class="arabic">اى كلام يتقال و خلاص المهم الحشو</li>
                                <li class="arabic">اى كلام يتقال و خلاص المهم الحشو</li>
                                <li class="arabic">اى كلام يتقال و خلاص المهم الحشو</li>
                                <li class="arabic">اى كلام يتقال و خلاص المهم الحشو</li>
                            </ul>
                            </li>
                        </ul>
                        
                    </div>

                </div>
            </section>
        </div>
    </div>
    <!-- End content -->

